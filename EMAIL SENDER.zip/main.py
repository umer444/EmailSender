# PYTHON EMAIL SENDER BY UMER AFTAB #
# SOME BASIC INFO (---IT WONT WORK UNTIL YOU DONT ON LESS SECURE APP USE ON EMAIL---)

import smtplib
from email.message import EmailMessage
from string import Template  # ---This is for Html FORMATED EMAIL
from pathlib import Path


html = Template(Path('index.html').read_text())
email = EmailMessage()
email['from'] = 'Umeraftab'
email['to'] = 'umeraftab4422@gmail.com'
email['subject'] = 'Hellow PYTHON MASTER'

# email.set_content("i am Python master") #---THIS IS FOR SIMPLE EMAIL NON DYNAMIC

# This for Index.html Temaplated Emails
email.set_content(html.substitute({"name": "umer aftab"}), "html")

with smtplib.SMTP(host="smtp.gmail.com", port=587) as smtp:
    smtp.ehlo()
    smtp.starttls()
    #smtp.login("EMAIL", "PASSWORD")
    smtp.login("ANYMAILHERE=@gmail.com", "PASSWORDHERE=123456789")
    smtp.send_message(email)
    print("DONE!!!!!")

    # SOME BASIC INFO (---IT WONT WORK UNTIL YOU DONT ON LESS SECURE APP USE ON EMAIL---)
